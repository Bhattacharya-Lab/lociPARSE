import pandas as pd
import scipy.stats

import numpy as np
import sys,os,shutil,math
from sklearn.preprocessing import StandardScaler,MinMaxScaler
import csv
from pprint import pprint
from sklearn.metrics import roc_auc_score, precision_recall_curve, auc

np.set_printoptions(threshold=sys.maxsize)
np.set_printoptions(suppress=True)

import torch
import torch.nn as nn

from tqdm import tqdm

def loadPredGNN(prefix):
	
	toolname = "lociPARSE"
	
	filename = f"{prefix}.txt"
	
	with open(filename, "r") as rfile:
		lines = rfile.readlines()

	pzcount = 0

	for pzid in lines:
		
		pzid = pzid.rstrip()
		
		arr = np.loadtxt(f"Ground_truth/{pzid}/lDDT.txt")
		count = arr.shape[0]
		
		scorelistdecoy = []

		for i in tqdm(range(count)):
			num = i + 1
			
			dec_pfx = f"{pzid}_decoy_{num}"
		
			predpath = f"../Prediction/{dec_pfx}/score.txt"
			
			with open(predpath, "r") as rfile:

				lines = rfile.readlines()

			first_value = float(lines[0])
			confval = float(lines[0])
			scorelistdecoy.append(confval)
			
			confarrlocal = []

			for line in lines[1:]:
				parts = line.split()
				if len(parts) == 2:
					confarrlocal.append(float(parts[1]))

			#break

			#os.remove(f"Predictions/{pzid}/Local/{toolname}_lddt_{num}.npy")
			if prefix != "ARES_benchmark2":
				np.save(f"Predictions/{pzid}/Local/{toolname}_lddt_{num}.npy", np.array(confarrlocal))
		
		confarr = np.array(scorelistdecoy)
		
		#os.remove(f"Predictions/{pzid}/{toolname}.txt")
		np.savetxt(f"Predictions/{pzid}/{toolname}.txt", confarr, fmt = "%.2f")

		pzcount += 1

		#break
		
def calculateCoefficient_diff(prefix, tool, scoreid):
	
	filename = f"{prefix}.txt"
	
	glist = []
	llist = []
	difflist = []

	with open(filename, "r") as rfile:
		lines = rfile.readlines()

	pzcount = 0

	sumcoeff1 = 0
	sumcoeff2 = 0
	sumcoeff3 = 0
	
	energytools = ["rsRNASP", "cgRNASP", "DFIRE", "RASP"]
	rmsdtools = ["Ares", "RNA3DCNN"]
	
	score1 = "AllRMSD"
	#zxcf
	#For each target

	scaler = MinMaxScaler(feature_range=(0, 1))
						
	for pzid in lines:
		
		pzid = pzid.rstrip()
		
		arr = np.loadtxt(f"Ground_truth/{pzid}/lDDT.txt")
		count = arr.shape[0] #decoy count of that target
		
		arr = np.load(f"Ground_truth/{pzid}/Local/lddt_1.npy", allow_pickle=True)
		L = arr.shape[0] #Length of that decoy

		#print(pzid, L)

		originalshape = count

		filename = f"Ground_truth/{pzid}/{scoreid}.txt"
		
		#===============calculation=======================

		if os.path.exists(filename) and os.path.getsize(filename) > 0:
			scores_GT = np.loadtxt(filename)
			newshape = scores_GT.shape[0]

			if originalshape == newshape:
				
				if all(np.isfinite(x) for x in scores_GT.flatten()):
					
					#Load predictions and convert to s-score 
					#========================================================
					decoyenergyfilename = f"Predictions/{pzid}/{tool}.txt"
					
					pred = np.loadtxt(decoyenergyfilename)
					pred = pred.reshape(-1, 1)
					
					if tool in rmsdtools:
						d0 = 1.24 * (math.pow(L-15, 1/3)) - 1.8
						pred_minimized = 1 / (1 + (pred / d0)**2)
					else:
						pred_minimized = pred
					
					#========Complete=======================================

					scores_GT = scores_GT.reshape(-1, 1)
					
					# Normalize ground truth only if RMSD
					#===================================
					if (scoreid == score1):
						d0 = 1.24 * (math.pow(L-15, 1/3)) - 1.8
						scores_GT_minimized = 1 / (1 + (scores_GT / d0)**2)
					else:
						scores_GT_minimized = scores_GT
						
					#==========Reverse predictions======

					if tool in energytools:
						#pred_minimized = scaler.fit_transform(pred_minimized)
						pred_minimized =  1.0 -  pred_minimized

					if np.all(scores_GT_minimized == scores_GT_minimized[0]) or np.all(pred_minimized == pred_minimized[0]):
						print(f"{pzid} either all score same or all pred same")
						continue
					else:
						if pzcount == 0:
							x = scores_GT_minimized
							y = pred_minimized
						else:	
							x = np.concatenate((x,scores_GT_minimized), axis = 0)
							y = np.concatenate((y, pred_minimized), axis = 0)
							
						scores_GT_minimized = scores_GT_minimized.flatten()
						pred_minimized = pred_minimized.flatten()

						coeff1, _ = scipy.stats.pearsonr(scores_GT_minimized, pred_minimized)
						coeff2, _ = scipy.stats.spearmanr(scores_GT_minimized, pred_minimized)
						coeff3, _ = scipy.stats.kendalltau(scores_GT_minimized, pred_minimized)

						sumcoeff1 += coeff1
						sumcoeff2 += coeff2
						sumcoeff3 += coeff3

						#print(pzid,coeff1,coeff2,coeff3)

						pzcount += 1
						
				else:
					print(f"{pzid} problem in predictions, some are not finite??")	
			else:
				print(f"{pzid} # of decoy for the id and # of value in score file dont match")
		else:
			print(f"{pzid} BH the entire score file is missing")
		
		#break
	
	if tool in energytools:
		y = scaler.fit_transform(y)
		
	x = x.squeeze()
	y = y.squeeze()

	#print(x.shape,y.shape)
	
	globcoeff1, _ = scipy.stats.pearsonr(x, y)
	globcoeff2, _ = scipy.stats.spearmanr(x, y)
	globcoeff3, _ = scipy.stats.kendalltau(x, y)
	
	globcoeff1 = float("{:.2f}".format(globcoeff1))
	globcoeff2 = float("{:.2f}".format(globcoeff2))
	globcoeff3 = float("{:.2f}".format(globcoeff3))

	avgcoeff1 =  float("{:.2f}".format(sumcoeff1 / pzcount))
	avgcoeff2 =  float("{:.2f}".format(sumcoeff2 / pzcount))
	avgcoeff3 =  float("{:.2f}".format(sumcoeff3 / pzcount))
	
	#print(pzcount)
	
	glist.append(globcoeff1)
	glist.append(globcoeff2)
	glist.append(globcoeff3)

	llist.append(avgcoeff1)
	llist.append(avgcoeff2)
	llist.append(avgcoeff3)

	x = x.reshape(-1,1)
	y = y.reshape(-1,1)
	
	diffval = abs(x - y)
	
	dataset_wise_avg =  float("{:.2f}".format(np.average(diffval)))
	
	#print(pzcount)
	
	difflist.append(dataset_wise_avg)
	
	return glist,llist, difflist	

def calculateLoss(prefix, tool, scoreid):
	
	filename = f"{prefix}.txt"
	
	with open(filename, "r") as rfile:
		lines = rfile.readlines()

	pzcount = 0
	sumloss = 0
	
	score5 = "lDDT"
	score7 = "TMscore"

	max_arr = [score7, score5]

	losslist = []

	best_pred_top1 = []

	for pzid in lines:
		
		pzid = pzid.rstrip()
		
		arr = np.loadtxt(f"Ground_truth/{pzid}/lDDT.txt")
		count = arr.shape[0] #decoy count of that target
		
		originalshape = count

		filename = f"Ground_truth/{pzid}/{scoreid}.txt"
		
		#===============calculation=======================

		if os.path.exists(filename) and os.path.getsize(filename) > 0:
			scores_GT = np.loadtxt(filename)
			newshape = scores_GT.shape[0]

			if originalshape == newshape:
				
				if all(np.isfinite(x) for x in scores_GT.flatten()):
					
					#Load predictions and convert to s-score 
					#========================================================
					decoyenergyfilename = f"Predictions/{pzid}/{tool}.txt"
					
					pred = np.loadtxt(decoyenergyfilename)
					pred = pred.reshape(-1, 1)
					
					if np.all(scores_GT == scores_GT[0]) or np.all(pred == pred[0]):
						continue
					else:
						if scores_GT.shape[0] == pred.shape[0]:
							
							if scoreid in max_arr:
								bestscore_real = max(scores_GT)
							else:
								bestscore_real = min(scores_GT)
							
							if tool.startswith("loci"):
								best_pred = max(pred)
							else:
								best_pred = min(pred)
							
							bestpredindex = np.where(pred == best_pred)[0]
							#print(pzid)
							#print(best_pred,bestpredindex[0])

							bestscore_pred = scores_GT[bestpredindex[0]]
							#print(bestscore_pred)

							#print(bestscore_real, bestscore_pred)

							lossval = abs(bestscore_real - bestscore_pred)

							sumloss += lossval
							pzcount += 1

							best_pred_top1.append(bestscore_pred)

							#break

	avgloss =  float("{:.2f}".format(sumloss / pzcount))
	
	#print(tool)
	#print(pzcount)
	
	losslist.append(avgloss)

	#print(best_pred_top1, len(best_pred_top1))

	#print("Median:", np.median(best_pred_top1))

	
	return losslist

def calculateLocalDiff(prefix, tool, scoreid):
	
	#zxcf
	filename = f"{prefix}.txt"
	
	with open(filename, "r") as rfile:
		lines = rfile.readlines()

	pzcount = 0
	
	score1 = "AllRMSD"
	
	difflist = []

	concatcount = 0
	scaler = MinMaxScaler(feature_range=(0, 1))

	for pzid in lines:
		
		pzid = pzid.rstrip()
		
		arr = np.loadtxt(f"Ground_truth/{pzid}/lDDT.txt")
		count = arr.shape[0] #decoy count of that target
		
		arr = np.load(f"Ground_truth/{pzid}/Local/lddt_1.npy", allow_pickle=True)
		L = arr.shape[0] #Length of that decoy

		for i in range(count):
			
			num = i + 1
			
			filename = f"Ground_truth/{pzid}/Local/lddt_{num}.npy"
			
			if os.path.exists(filename):
				scores = np.load(filename, allow_pickle=True)

				decoyenergyfilename = f"Predictions/{pzid}/Local/{tool}_lddt_{num}.npy"
				
				pred = np.load(decoyenergyfilename)

				pred = pred.reshape(-1, 1)
				
				if scores.shape[0] == pred.shape[0]:
						
					pred = pred.reshape(-1,1)
					scores = scores.reshape(-1,1)

					if tool == "RNA3DCNN":
						pred = scaler.fit_transform(pred)
						pred = 1.0 - pred
					
					if concatcount == 0:
						x = scores 
						y = pred
					else:	
						x = np.concatenate((x,scores), axis = 0)
						y = np.concatenate((y, pred), axis = 0)

					#print(decoyenergyfilename, min(pred),max(pred))
					concatcount += 1	
			
		pzcount += 1

		#break

	# Create a boolean mask for None values
	none_mask = x == None

	none_count = np.sum(x == None)

	#print(f"Number of None values: {none_count}")

	# Replace None values with 0
	x[none_mask] = 0

	diffval = abs(x - y)

	dataset_wise_avg =  float("{:.2f}".format(np.average(diffval)))

	x = np.squeeze(x)
	y = np.squeeze(y)
	
	globcoeff1, _ = scipy.stats.pearsonr(x, y)
	globcoeff2, _ = scipy.stats.spearmanr(x, y)
	globcoeff3, _ = scipy.stats.kendalltau(x, y)
	
	globcoeff1 = float("{:.2f}".format(globcoeff1))
	globcoeff2 = float("{:.2f}".format(globcoeff2))
	globcoeff3 = float("{:.2f}".format(globcoeff3))

	#print(pzcount)
	
	difflist.append(globcoeff1)
	difflist.append(globcoeff2)
	difflist.append(globcoeff3)
	difflist.append(dataset_wise_avg)

	return difflist

def calculateAUC(prefix, tool, scoreid):
	
	#zxcf
	filename = f"{prefix}.txt"
	
	with open(filename, "r") as rfile:
		lines = rfile.readlines()

	pzcount = 0
	sum_avg_roc = 0
	zerocount = 0
	totalcount = 0
	
	roc_pr_list = []

	energytools = ["rsRNASP", "cgRNASP", "DFIRE", "RASP"]
	rmsdtools = ["Ares", "RNA3DCNN"]

	scaler = MinMaxScaler(feature_range=(0, 1))

	for pzid in lines:
		
		pzid = pzid.rstrip()
		
		arr = np.loadtxt(f"Ground_truth/{pzid}/lDDT.txt")
		count = arr.shape[0] #decoy count of that target
		
		arr = np.load(f"Ground_truth/{pzid}/Local/lddt_1.npy", allow_pickle=True)
		L = arr.shape[0] #Length of that decoy
		
		originalshape = count

		filename = f"Ground_truth/{pzid}/{scoreid}.txt"
		
		#===============calculation=======================

		if os.path.exists(filename) and os.path.getsize(filename) > 0:
			scores = np.loadtxt(filename)
			newshape = scores.shape[0]

			if originalshape == newshape:
				
				if all(np.isfinite(x) for x in scores.flatten()):
					
					#Load predictions and convert to s-score 
					#========================================================
					decoyenergyfilename = f"Predictions/{pzid}/{tool}.txt"
					
					pred = np.loadtxt(decoyenergyfilename)
					pred = pred.reshape(-1, 1)

					if np.all(scores == scores[0]) or np.all(pred == pred[0]):
						continue
					else:
						if scores.shape[0] == pred.shape[0]:
							
							pred = pred.reshape(-1,1)
							scores = scores.reshape(-1,1)
							
							bin_score = np.zeros_like(scores)
							threshold = 0.75
							bin_score[scores >= threshold] = 1
							
							#Load predictions and convert to s-score 
							#========================================================
							if tool in rmsdtools:
								d0 = 1.24 * (math.pow(L-15, 1/3)) - 1.8
								pred_minimized = 1 / (1 + (pred / d0)**2)
							else:
								pred_minimized = pred
							
							#==========Reverse predictions======

							if tool in energytools:
								#pred_minimized = scaler.fit_transform(pred_minimized)
								pred_minimized =  1.0 -  pred_minimized

							if pzcount == 0:
								x = bin_score
								y = pred_minimized
							else:	
								x = np.concatenate((x,bin_score), axis = 0)
								y = np.concatenate((y, pred_minimized), axis = 0)

							pzcount += 1							

		#break

	if tool in energytools:
		y = scaler.fit_transform(y)

	global_avg_roc_auc = float("{:.2f}".format(roc_auc_score(x, y)))
	
	precision, recall, thresholds = precision_recall_curve(x, y)
	pr_auc = auc(recall, precision)
	global_avg_pr_auc = float("{:.2f}".format(pr_auc))

	roc_pr_list.append(global_avg_roc_auc)
	#roc_pr_list.append(global_avg_pr_auc)
	#print(tool)
	
	#print(pzcount)
	#print(zerocount,totalcount)

	#print(f"Actual class 0 perct in terms of lDDT = {(zerocount * 100) / totalcount} %")
	
	return roc_pr_list

def EvaluateQA(datasetname):
	
	score1 = "AllRMSD"
	score5 = "lDDT"
	
	if datasetname == "ARES_benchmark2":
		datasets = ["ARES_benchmark2"]
		scores_arr = [score1]

	else:
		datasets = ["Test30", "CASP15"]
		scores_arr = [score1, score5]

	if not os.path.exists("Results/"):
		os.makedirs("Results/")

	for dataset in datasets:
		
		outstr = "Results/" + dataset

		if not os.path.exists(outstr):
			os.makedirs(outstr)
			
		for scoreid in scores_arr:
			
			#==========Coefficient==========================
			if dataset != "ARES_benchmark2":
				if dataset == "Test30" and scoreid == "lDDT":
					tools = ["lociPARSE", "rsRNASP", "RASP", "Ares", "DFIRE", "cgRNASP", "RNA3DCNN"]
				if dataset == "Test30" and scoreid == "AllRMSD":
					tools = ["lociPARSE", "Ares", "RASP", "rsRNASP", "DFIRE", "cgRNASP", "RNA3DCNN"]
				if dataset == "CASP15" and scoreid == "lDDT":
					tools = ["lociPARSE", "Ares", "RASP", "rsRNASP", "DFIRE", "cgRNASP", "RNA3DCNN"]
				if dataset == "CASP15" and scoreid == "AllRMSD":
					tools = ["lociPARSE", "Ares", "rsRNASP", "cgRNASP", "RASP",  "DFIRE", "RNA3DCNN"]
			else:
				if scoreid == "AllRMSD":
					tools = ["lociPARSE", "Ares"]

			fullscorelist = []

			for tool in tools:
				
				toolname = [tool]

				glist, llist, difflist = calculateCoefficient_diff(dataset, tool, scoreid)
				losslist = calculateLoss(dataset, tool, scoreid)
				
				if scoreid == score5:
					AUClist = calculateAUC(dataset, tool, scoreid)
				else:
					AUClist = [0]
				
				if scoreid == score5 and (tool.startswith("loci") or tool == "RNA3DCNN"):
					if dataset != "ARES_benchmark2":
						localdifflist = calculateLocalDiff(dataset, tool, scoreid)
					else:
						localdifflist = [0,0,0,0]
				else:
					localdifflist = [0,0,0,0]
				
				#Append these 3 correctly.
				
				if dataset == "Test30" and scoreid == "lDDT":
					fullscorelistperMethod = toolname + glist + difflist + AUClist + llist + losslist
					columns = ['Methods', 'Global_r',	'Global_⍴',	'Global_𝜏', 'Diff', 'ROC', 'Avg_r', 'Avg_⍴', 'Avg_𝜏',  'Avg Loss']
				if dataset == "Test30" and scoreid == "AllRMSD":
					fullscorelistperMethod = toolname + glist + difflist + llist + losslist
					columns = ['Methods', 'Global_r',	'Global_⍴',	'Global_𝜏', 'Diff', 'Avg_r', 'Avg_⍴', 'Avg_𝜏',  'Avg Loss']
				if dataset == "CASP15" and scoreid == "lDDT":
					fullscorelistperMethod = toolname + glist + difflist + AUClist + llist + losslist + localdifflist
					columns = ['Methods', 'Global_r',	'Global_⍴',	'Global_𝜏', 'Diff', 'ROC', 'Avg_r', 'Avg_⍴', 'Avg_𝜏',  'Avg Loss', 'Global_r',	'Global_⍴',	'Global_𝜏', 'Diff']
				if dataset == "CASP15" and scoreid == "AllRMSD":
					fullscorelistperMethod = toolname + glist + difflist + llist + losslist
					columns = ['Methods', 'Global_r',	'Global_⍴',	'Global_𝜏', 'Diff', 'Avg_r', 'Avg_⍴', 'Avg_𝜏',  'Avg Loss']
				if dataset == "ARES_benchmark2" and scoreid == "AllRMSD":
					fullscorelistperMethod = toolname + glist + difflist + llist + losslist
					columns = ['Methods', 'Global_r',	'Global_⍴',	'Global_𝜏', 'Diff', 'Avg_r', 'Avg_⍴', 'Avg_𝜏',  'Avg Loss']
					
				fullscorelist.append(fullscorelistperMethod)
			
			if dataset == "Test30" and scoreid == "lDDT":
				filename = f"{outstr}/{scoreid}_Table1.xlsx"
			if dataset == "Test30" and scoreid == "AllRMSD":
				filename = f"{outstr}/{scoreid}_Table2.xlsx"
			if dataset == "CASP15" and scoreid == "lDDT":
				filename = f"{outstr}/{scoreid}_Table3_and_5.xlsx"
			if dataset == "CASP15" and scoreid == "AllRMSD":
				filename = f"{outstr}/{scoreid}_Table4.xlsx"
			if dataset == "ARES_benchmark2" and scoreid == "AllRMSD":
				filename = f"{outstr}/{scoreid}_Table6.xlsx"

			if os.path.exists(filename):
				os.remove(filename)
			
			# Create the DataFrame
			df = pd.DataFrame(fullscorelist, columns=columns)

			# Write the DataFrame to an Excel file
			df.to_excel(filename, index=False, engine='openpyxl')

			from openpyxl import load_workbook
			from openpyxl.styles import Font

			# Load the workbook and select the active sheet
			wb = load_workbook(filename)
			ws = wb.active

			# Apply bold font to the header row
			for cell in ws[1]:
				cell.font = Font(bold=True)

			# Save the workbook
			wb.save(filename)

			#break

			print(dataset, scoreid)
			print("Done")

if __name__ == '__main__':

	datasetname = sys.argv[1]

	predcition = int(sys.argv[2])

	if predcition == 1:

		if datasetname == "Test30_CASP15":
			loadPredGNN("Test30")
			loadPredGNN("CASP15")
		else:
			loadPredGNN("ARES_benchmark2")

	EvaluateQA(datasetname)
	