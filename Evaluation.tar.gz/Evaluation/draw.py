import pandas as pd
import scipy.stats

import numpy as np
import sys,os,shutil,math,heapq
from sklearn.preprocessing import StandardScaler,MinMaxScaler
import csv
from pprint import pprint
from sklearn.metrics import roc_auc_score, precision_recall_curve, auc

import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import seaborn as sns

np.set_printoptions(threshold=sys.maxsize)
np.set_printoptions(suppress=True)

def find_next_index(lst, value, current_index):
	try:
		next_index = lst.index(value, current_index + 1)
	except ValueError:
		next_index = None
	return next_index

def calculateLoss(prefix, tool, scoreid, topN):
	
	filename = f"{prefix}.txt"
	
	with open(filename, "r") as rfile:
		lines = rfile.readlines()

	pzcount = 0
	sumloss = 0
	sumNloss = 0
	
	score5 = "lDDT"
	score7 = "TMscore"

	max_arr = [score7, score5]

	losslist = []

	best_pred_topN = []
	
	for pzid in lines:
		
		pzid = pzid.rstrip()
		
		arr = np.loadtxt(f"Ground_truth/{pzid}/lDDT.txt")
		count = arr.shape[0] #decoy count of that target

		originalshape = count

		filename = f"Ground_truth/{pzid}/{scoreid}.txt"
		
		#===============calculation=======================

		if os.path.exists(filename) and os.path.getsize(filename) > 0:
			scores_GT = np.loadtxt(filename)
			newshape = scores_GT.shape[0]

			if originalshape == newshape:
				
				if all(np.isfinite(x) for x in scores_GT.flatten()):
					
					#Load predictions and convert to s-score 
					#========================================================
					decoyenergyfilename = f"Predictions/{pzid}/{tool}.txt"
					
					pred = np.loadtxt(decoyenergyfilename)
					pred = pred.reshape(-1, 1)
					
					if np.all(scores_GT == scores_GT[0]) or np.all(pred == pred[0]):
						continue
					else:
						if scores_GT.shape[0] == pred.shape[0]:
							
							#top-N
							#================
							pred = list(pred)
							N = topN
	
							if tool.startswith("loci"):
								top_predictions = heapq.nlargest(N, pred)
							else:
								top_predictions = heapq.nsmallest(N, pred)

							top_prediction_indices = []
							
							for i,elem in enumerate(top_predictions):
								top_predictions[i] = elem[0]
							
							#print(top_predictions)
							
							for i, item in enumerate(top_predictions):
								index = pred.index(item)
								
								if index not in top_prediction_indices:
									top_prediction_indices.append(index)
								else:
									
									next_index = find_next_index(pred, item, top_prediction_indices[-1])
									top_prediction_indices.append(next_index)

							#print(top_prediction_indices)
							
							bestscore_list = [] #Actual scores of those top prediction

							for i, item in enumerate(top_prediction_indices):
								bestscore_list.append(scores_GT[top_prediction_indices[i]])

							#print(bestscore_list)

							if scoreid == "lDDT":
								best_pred_topN.append(max(bestscore_list))
							else:
								best_pred_topN.append(min(bestscore_list))
							
							#break

	return np.median(best_pred_topN)

def format_ticks(x,pos):
	if x == 0.0:
		return f'{int(round(x))}'
	else:
		return float("{:.2f}".format(x))
	
def format_ticks2(x,pos):
	return f'{int(round(x))}'


def drawLoss(data_to_plot, labels,dataset, scoreid, flag, count, topN):

	scores = data_to_plot

	for i, item in enumerate(scores):
		scores[i] = float("{:.2f}".format(scores[i]))

	maxlim = max(scores)

	methods = ["lociPARSE", "cgRNASP", "DFIRE", "rsRNASP", "Ares",  "RNA3DCNN", "RASP"]
	
	df = pd.DataFrame({'Methods': methods, 'Loss': scores})
	
	palette = ["#1F77B4"]

	if scoreid == "lDDT" and flag == 1 and count == 0:
		ax = sns.barplot(data=df, y = "Methods", x = "Loss", orient = 'h', width = 0.6, dodge=False, color='#6C9EEB')
	else:
		ax = sns.barplot(data=df, y = "Methods", x = "Loss", orient = 'h', width = 0.6,
			order=df.sort_values('Loss', ascending = False).Methods, dodge=False, color='#6C9EEB')
	
	# Annotate values on top of bars
	for p in ax.patches:
		if flag !=3 :
			if scoreid == "lDDT":
				buff = 0.04
			else:
				if dataset == "CASP15":
					if flag == 1:
						buff = 1.5
					else:
						buff = 0.99
				else:
					buff = 0.05 * maxlim
		else:
			if scoreid == "lDDT":
				buff = 0.007
			else:
				if dataset == "CASP15":
					buff = 0.8
				else:
					buff = 0.05 * maxlim
	

	ax = plt.gca() 
	ax.xaxis.set_major_formatter(FuncFormatter(format_ticks))

	ax.set_xlim(xmin=0.0, xmax=maxlim+ 0.15 * maxlim) #0.408
	
	if flag == 1:
		if dataset != "Ares2":
			titlestr = f"{dataset}"
		else:
			titlestr = f"Ares benchmark 2"
	elif flag == 2:
		if dataset != "Ares2":
			if scoreid == "lDDT":
				titlestr = f"{dataset}"
			else:
				titlestr = f"{dataset}"
		else:
			if scoreid == "lDDT":
				titlestr = f"Ares benchmark 2"
			else:
				titlestr = f"Ares benchmark 2"
	else:
		if dataset != "Ares2":
			titlestr = f"{dataset} | {scoreid}"
		else:
			titlestr = f"Ares benchmark 2 | {scoreid}"

	ax.set_title(titlestr)
	
	if flag == 3:
		xlabelstr = f'Mean top-N loss'
	else:
		xlabelstr = f'Median {scoreid}'
	plt.xlabel(xlabelstr, fontsize=14)
	#plt.ylabel('Methods', fontsize=14)
	plt.ylabel('')

	plt.xticks(fontsize=13)
	plt.yticks(fontsize=13)
			
	plt.tight_layout()		

	plt.savefig(f"Figures/Top_{topN}_median_{scoreid}_{dataset}.png", bbox_inches='tight', dpi= 350, transparent=False)
	
	plt.close()


def top_rank_QA():

	score1 = "lDDT"
	score2 = "AllRMSD"
	
	scores_arr = [score1, score2]

	datasets = ["Test30", "CASP15"]
	
	count = 0

	for dataset in datasets:
		
		for scoreid in scores_arr:
			
			#==========Coefficient==========================
			
			tools = ["lociPARSE", "cgRNASP", "DFIRE", "rsRNASP", "Ares",  "RNA3DCNN", "RASP"]
			
			top_score = []
			
			topN = 10

			if topN == 1:
				flag = 1
			else:
				flag = 2

			for tool in tools:
				
				#print(scoreid, tool)

				s = calculateLoss(dataset, tool, scoreid, topN)

				top_score.append(s)
	
			drawLoss(top_score, tools, dataset, scoreid, flag, count, topN)
		   
			count += 1

			print(dataset, scoreid)
			print("Done")

if __name__ == '__main__':
	
	top_rank_QA()

